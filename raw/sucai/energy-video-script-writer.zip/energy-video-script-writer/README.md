# energy-video-script-writer · 可移植技能包

> 《能源行业智能转型案例说》栏目的**案例抓取 → 文稿 → 宣发物料**一键工作流。
> 本包已做「去本机路径」处理，可装载到任意支持 Skill 的 agent 中复用。

## 一、这个技能干什么

跑完一条工作流，**每期默认交付两份文档**：

| # | 交付物 | 格式 | 内容 |
|---|---|---|---|
| 1 | `EPxxx-片名-视频文稿.md` | Markdown | 抓取的案例，六段式 1200 字文稿（案例卡片 + 分段解说词 + 信源清单 + 事实核查） |
| 2 | `EPxxx-片名-宣发物料.docx` | Word | 标题（≤20 字）+ 简介（≤200 字）+ 16:9 高清横版封面图，排版进一个 Word |

其余（文稿 Word / 分镜 Excel / 时间轴 JSON / 素材清单）都是**按需产物**，用户开口要才生成。

## 二、目录结构

```
energy-video-script-writer/
├── SKILL.md                       # 主控：栏目定位、标准工作流、命令速查、约束
├── README.md                      # 本文件：装载与使用说明
├── requirements.txt               # Python 依赖清单
├── assets/
│   ├── skeleton.md                # 文稿 Markdown 骨架（含「宣发物料」章节）
│   └── storyboard.template.md     # 素材归集清单模板（按需）
├── references/
│   ├── script-template.md         # 六段式模板、案例卡片、事实核查清单
│   ├── scheduling-rules.md        # 选题储备池排期准则
│   ├── promo-spec.md              # 宣发物料规范（标题/简介/封面图写法）
│   ├── delivery-spec.md           # 交付物矩阵、命令速查、环境依赖
│   └── preproduction.md           # 时间轴/素材/时长（按需）
└── scripts/                       # 可执行脚本（纯 Python，相对引入，无硬编码路径）
    ├── epmd.py                    # 共享 md 解析模块（其余脚本共用）
    ├── count_chars.py             # 字数复核（定稿前必跑）
    ├── build_promo_docx.py        # ★ 宣发物料 → Word（核心）
    ├── md_to_docx.py              # 文稿 md → docx（按需，依赖 WorkBuddy 插件）
    ├── build_timeline.py          # 文稿 → 时间轴 JSON（按需）
    └── build_shotlist_xlsx.py     # 文稿 → Excel 分镜表（按需）
```

## 三、装载方法

1. 把整个 `energy-video-script-writer/` 目录放到目标 agent 的 **skills 目录**下
   （WorkBuddy 是 `~/.workbuddy/skills/`，其他 agent 按其约定的 skills 路径）。
2. 装 Python 依赖：

   ```bash
   pip install -r requirements.txt
   ```

3. 若目标 agent 支持 `@skill:` 挂载，直接用 skill 名 `energy-video-script-writer` 唤起；
   否则把 `SKILL.md` 全文作为系统提示注入该 agent 即可。

## 四、核心工作流（自动跑）

1. **抓案例 / 定选题**：检索近期官媒报道，按《财富》500 强排名优先遴选（见 `scheduling-rules.md`）。
2. **信源与事实核查**：锁定官媒信源，剔除单一信源/数量级矛盾数据。
3. **写 md 文稿**：按 `assets/skeleton.md` 填 11 部分 + 六段式解说词（1150–1200 字）。
4. **写宣发三件套**：填 md 的「## 2. 宣发物料」章节——标题、简介、封面图提示词。
5. **生成封面图**：用目标 agent 的文生图能力出图（横版高清，尽量 3:2 或 16:9）。
   ⚠️ 出图消耗额度，**出图前必须告知用户**。
6. **生成宣发 Word**：

   ```bash
   python3 scripts/build_promo_docx.py "EP001-片名-视频文稿.md" \
         "EP001-片名-宣发物料.docx" "封面原图.png"
   ```

   脚本自动：居中裁成 16:9（只裁不拉伸）→ 卡字数（标题 ≤20、简介 ≤200，超限报错）→ 排版进 Word。

## 五、封面图怎么办（重要）

- 封面图依赖目标 agent 的**文生图能力**（如 ImageGen）。若该 agent 有图生能力，按 md 里的
  「封面图提示词」出图即可；提示词写法见 `references/promo-spec.md` 第四节。
- 若目标 agent **没有**文生图能力：`build_promo_docx.py` 会自动降级为「只排版标题 + 简介」，
  Word 仍能交付，封面留待人工补图后重跑一次即可。
- 封面图务必遵守：不画文字/logo/真人面孔、涉及地图不画图（合规硬要求）。

## 六、可选产物（按需，别全生成）

| 用户要什么 | 命令 |
|---|---|
| 文稿 Word | `python3 scripts/md_to_docx.py 文稿.md 输出.docx` |
| 时间轴 JSON | `python3 scripts/build_timeline.py 文稿.md 输出.json --cps 4.0` |
| Excel 分镜表 | `python3 scripts/build_shotlist_xlsx.py 文稿.md 输出.xlsx [时间轴.json]` |
| 素材清单 | 按 `assets/storyboard.template.md` 填 |

> `md_to_docx.py` 依赖 WorkBuddy 的 tencent-docx 插件（`html_to_docx`），在非 WorkBuddy agent 里
> 可能不可用；不影响核心工作流。插件目录与解释器可用环境变量覆盖：
> `TENCENT_DOCX_PLUGIN`、`HTML_TO_DOCX_PY`。

## 七、硬约束（任何时候都生效）

- 默认只交两份：md 文稿 + 宣发 Word；其余按需，不要自作主张全生成。
- **不生成任何音频文件**（配音由用户自理）。
- **不做片头**（已移除，时间轴从 0 秒直进 ① 段）。
- **工作流：先出文稿 → 用户确认 → 再进视频生成**，确认环节不得跳过。
- 地图合规：标准底图、国界线完整。
