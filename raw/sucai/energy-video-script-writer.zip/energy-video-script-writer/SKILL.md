---
name: energy-video-script-writer
description: "For the daily column 《能源行业智能转型案例说》—global energy-industry intelligent/digital transformation cases. Covers: 抓取/选题 → 六段式 1200字 md 文稿 → 宣发物料（标题≤20字 + 简介≤200字 + 16:9 封面图，打包进 Word）→ on-demand docx / Excel 分镜脚本表 / 时间轴工程 JSON / 素材归集清单. Default deliverables are the md script AND the promo Word doc; everything else is on-demand. NO 片头 (removed 2026-09-03); NEVER generates audio files. Hard workflow: 先出文稿 → 用户确认 → 再生成视频. Triggers include 写一期文稿, 出 EPxxx 的解说词, 生成封面图, 排一下选题, 选题储备池怎么排, or any request to produce energy-transformation case video scripts for this column."
agent_created: true
---

# 能源行业智能转型案例说 · 案例抓取与文稿制作

## 栏目定位

- 每日更新的短视频栏目，挖掘**全世界**能源行业智能转型案例。
- **工作流硬约束：先出文稿 → 用户确认 → 再生成视频。** 不得跳过确认环节。
- **交付口径（用户 2026-09-03 明确）**：
  1. **每期默认交付两份**：
     - `EPxxx-片名-视频文稿.md` —— 六段式文稿
     - `EPxxx-片名-宣发物料.docx` —— 标题（≤20 字）+ 简介（≤200 字）+ 16:9 封面图
  2. 文稿 docx / 分镜 xlsx / 时间轴 JSON / 素材归集清单 全是**按需产物**——用户明确要了才生成。
     拿不准就只交 md + 宣发 Word，回复里补一句「需要文稿 Word / 脚本表 / 时间轴我再补」。
  3. **不生成 mp3 等任何音频文件。** 配音由用户自理。
  4. **不做片头。** 无片头设计章节、无片头时长约束，时间轴从 0 秒直进 ① 段。

## 何时使用本技能

- 抓取/遴选某期能源行业智能转型案例；建立、扩充或重排「选题储备池」。
- 撰写/打磨某期解说词；生成标题、简介、封面图与宣发 Word。
- 用户点名要文稿 Word、脚本表、时间轴、素材清单等派生产物。
- 用户引用 EP 编号（EP001、EP002…）要求出稿或补产物。

## 文件地图

| 文件 | 用途 |
|---|---|
| `references/script-template.md` | 六段式模板、案例卡片、3 条辨识度要求、11 部分结构、事实核查清单 |
| `references/scheduling-rules.md` | 选题储备池排期准则（按企业体量/《财富》500 强排名）+ 穿插方向 |
| `references/promo-spec.md` | **宣发物料规范**：标题/简介写法、封面图提示词、ImageGen 链路、交付必查 |
| `references/delivery-spec.md` | **交付物矩阵、触发语判断、命令速查、环境依赖** |
| `references/preproduction.md` | 时间轴 JSON schema、素材类型判定、成片时长公式、产出后必查项 |
| `assets/skeleton.md` | 可直接套用的 11 段式文稿 Markdown 骨架（含宣发物料章节） |
| `assets/storyboard.template.md` | 素材归集清单模板（官媒需求 / 图库检索词 / 自制素材三张表） |
| `scripts/epmd.py` | **共享 md 解析模块**，五个脚本共用；改解析规则只改这里 |
| `scripts/count_chars.py` | 字数复核（定稿前必跑） |
| `scripts/build_promo_docx.py` | **宣发物料 → Word**（标题/简介/16:9 封面图），卡字数上限 |
| `scripts/md_to_docx.py` | md → docx（文稿全文） |
| `scripts/build_timeline.py` | md → 时间轴工程 JSON（重跑保留已填 shots，无 head 块） |
| `scripts/build_shotlist_xlsx.py` | md（+ 时间轴）→ Excel 分镜脚本表 |

## 标准工作流

1. **抓取案例 / 确定选题**：检索近期官媒报道，从储备池选（或经用户确认），优先企业体量/《财富》500 强排名靠前者。
2. **信源核查**：核实事实，锁定官媒信源（新华社、央视、人民日报等）。记录信源清单与单一信源风险。
3. **事实核查**：剔除数量级矛盾或仅单一信源的数据；无法交叉验证的在文稿中明示「待核实」。
4. **撰写文稿**：按 `assets/skeleton.md` 的 11 部分 + `references/script-template.md` 的六段式填写。语速基准 **4.0 字/秒**，5 分钟对应解说 **1150–1200 字**。
5. **字数复核（必做，易踩坑）**：**初稿目测普遍偏少 100 字左右，必须实算。** 跑 `scripts/count_chars.py`，落在 1150–1200 才算合格。
6. **写宣发三件套**：填 md 的「宣发物料」章节——标题 ≤20 字、简介 ≤200 字、封面图提示词。写法见 `references/promo-spec.md`。
7. **生成封面图**：用 ImageGen 出图（`size="1536x1024"`，`quality="high"`）。
   ⚠️ **每次约 5–10 积分，出图前必须告知用户。**
8. **生成宣发 Word**：跑 `scripts/build_promo_docx.py`，脚本自动居中裁成 16:9、卡字数、排版。
9. **交付两份**：`EPxxx-片名-视频文稿.md` + `EPxxx-片名-宣发物料.docx`（附带 16:9 封面 PNG）。
10. **暂停，等用户确认**——不自动进视频生成，不生成任何音频。

## 按需产物（用户明确要了才做）

统一变量（可移植，首次使用先装依赖 `pip install -r requirements.txt`）：

```bash
S=<本技能目录>/scripts        # 技能装好后所在的 scripts 子目录
PY=python3                    # 环境 python3（已装 requirements.txt 依赖）
```

| 用户说 | 命令 |
|---|---|
| 要文稿 Word / docx / 评审稿 | `"$PY" "$S/md_to_docx.py" <文稿.md> <输出.docx>` |
| 要时间轴 / 工程文件 / 对轨 | `"$PY" "$S/build_timeline.py" <文稿.md> <输出.json> --cps 4.0` |
| 要脚本表 / 分镜表 / Excel | `"$PY" "$S/build_shotlist_xlsx.py" <文稿.md> <输出.xlsx> [时间轴.json]` |
| 要素材清单 / 去哪找画面 | 按 `assets/storyboard.template.md` 填 |
| 要重出封面 / 换封面图 | `"$PY" "$S/build_promo_docx.py" <文稿.md> <宣发.docx> [新封面.png]` |

- xlsx 的第三个参数**可省略**：无时间轴时按段落估算时间码，有则逐镜头输出绝对入出点。
  旧时间轴 JSON 若含 `head` 块仍能正常读取（向后兼容），新生成的不含。
- 宣发 Word 的第三个参数（封面原图）**可省略**，脚本会在 docx / md 同目录自动找名字带
  `封面` / `cover` 的图片。字数超限直接报错退出（`--force` 可强行生成）。
- 依赖链：`文稿.md` → `count_chars`（校验）／`md_to_docx`／`build_timeline` → `build_shotlist_xlsx`；
  `文稿.md` + 封面图 → `build_promo_docx`。
- 环境细节、触发语判断见 `references/delivery-spec.md`；时间轴字段规范见 `references/preproduction.md`。
- **每次生成 xlsx 后必看脚本打印的「解说完整性」行**，出现 ❌ 说明解说与镜头错位，必须修。

## 信源核查经验（2026-08 实战）

- 新华网与中国电力报（中国能源新闻网）常发**同源通稿**，两篇不算两个独立信源。
- 央企官网 + 其下属研究院网站的转载，同属「企业内部信源体系」，关键数据（如「全球首个 XX」）需标注「企业自述」或补外部印证。
- 仅见商业平台（今日头条等）转载的数据，不入解说。

## 关键约束速查

- **默认交付两份**（2026-09-03）：`EPxxx-片名-视频文稿.md` + `EPxxx-片名-宣发物料.docx`。
  文稿 docx / xlsx / 时间轴 / 素材清单按需。
- **不做片头**（2026-09-03）：无片头章节、无 ≤6 秒约束，时间轴从 0 秒直进 ① 段。
- **宣发硬指标**：标题 ≤ 20 字、简介 ≤ 200 字、封面 16:9（1920×1080）。脚本卡口，超限报错。
- **封面图消耗额度**：ImageGen 每次约 5–10 积分，**出图前必须告知用户**。
  最大横版只有 1536×1024（3:2），必须靠 `build_promo_docx.py` 居中裁成 16:9。
- **不产出音频**：任何阶段不得生成 mp3/wav，配音由用户自理；时长按 4.0 字/秒估算。
- **地图合规（硬要求）**：标准地图底图、国界线完整（主权合规，非版权问题）。
- **素材版权**：画面优先官媒，缺口用 Pexels/Pixabay 补。**AI 不代下版权视频**，只出检索词。
- **只讲范式跃迁**：聚焦「智能」带来的范式跃迁（运维「事后维修」→「预测性维护」、调度「人工判断」→「全局协同」），不做「上了什么系统」的罗列。
- **国际/中国对照**：国际标杆与中国标杆交替或对照呈现。
- **案例卡片**：每期开头出标准信息框（行业赛道｜企业｜核心技术｜关键成效｜可复制指数）。
- **数据魂**：量化成效必须给前后对比，按效率/安全/经济/绿色四类组织。

## 与视频生成阶段的关系

本技能负责**四件事**：抓取/遴选案例 → 生成 md 文稿 → 生成宣发物料
（标题 + 简介 + 封面图，打包 Word）→ 按需出前期制作产物。

视频合成（OpenMontage/Remotion/moviepy 等）属独立后续阶段，
由用户在**确认文稿之后**另行发起，不在本技能范围内。
