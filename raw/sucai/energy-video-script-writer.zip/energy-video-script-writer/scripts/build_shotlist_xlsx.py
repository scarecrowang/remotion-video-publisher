#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""把《能源行业智能转型案例说》的视频文稿（md）拆成 **Excel 分镜脚本表**。

【按需产物】默认不生成；用户明确要「脚本表 / xlsx / 分镜表」时才跑。

用法:
    python build_shotlist_xlsx.py <文稿.md> <输出.xlsx> [时间轴.json]

- 有 <时间轴.json>：逐镜头输出，时间码为绝对入出点，解说词按句精确分配到镜头。
- 无 <时间轴.json>：逐段输出，时间码按 4.0 字/秒估算，镜头从 md 的「画面来源」列拆分。

产出 3 个 sheet：分镜脚本 / 段落总览 / 音乐音效。
依赖：openpyxl（托管 venv 已装）。解析逻辑共用 epmd.py。
"""

import io
import json
import os
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import epmd as E                                                    # noqa: E402

from openpyxl import Workbook                                        # noqa: E402
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side  # noqa: E402
from openpyxl.utils import get_column_letter                          # noqa: E402

HEAD_FILL = PatternFill("solid", fgColor="1F4E79")
HEAD_FONT = Font(color="FFFFFF", bold=True, size=11)
TITLE_FONT = Font(bold=True, size=13, color="1F4E79")
THIN = Side(style="thin", color="BFBFBF")
BORDER = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)
WRAP = Alignment(wrap_text=True, vertical="top")
CENTER = Alignment(horizontal="center", vertical="center", wrap_text=True)


def build(md_path, out_path, tl_path=None):
    doc = E.parse_md(md_path)
    segs = doc["segs"]
    tl = json.load(io.open(tl_path, encoding="utf-8")) if tl_path and os.path.exists(tl_path) else None

    rows = []          # 分镜脚本行
    overview = []      # 段落总览行
    idx = 0

    def add_row(seg_label, seg_name, start, end, desc, src, narration, note=""):
        nonlocal idx
        idx += 1
        official, stock = E.split_src(src)
        rows.append([
            idx, (seg_label + " " + (seg_name or "")).strip(),
            "%s – %s" % (E.fmt_tc(start), E.fmt_tc(end)),
            round(end - start, 1),
            desc, E.classify(src), official, stock,
            narration, note,
        ])

    if tl and "timeline" in tl:
        total = float(tl.get("total_duration_s") or 0)
        # 实测语速优先：measured_cps（TTS 实测）> cps（build_timeline 用的假设值）> 4.0
        cps = float(tl.get("measured_cps") or tl.get("cps") or E.DEFAULT_CPS)
        for blk in tl["timeline"]:
            seg_label = blk.get("seg", "")
            seg_name = blk.get("name", "")
            bstart, bend = float(blk["start"]), float(blk["end"])
            dur = bend - bstart
            shots = blk.get("shots") or []
            narration = segs[seg_label]["narration"] if seg_label in segs else ""

            if not shots:
                v = segs.get(seg_label, {}).get("visual", "")
                add_row(seg_label, seg_name, bstart, bend, v or (seg_name + "（整段）"),
                        v, narration, "镜头待细分")
                overview.append([seg_label or blk["id"], seg_name, segs.get(seg_label, {}).get("chars", ""),
                                 E.fmt_tc(bstart), E.fmt_tc(bend), round(dur, 1), narration])
                continue

            wins = [E.parse_rel_window(s.get("t", ""), dur) for s in shots]
            buckets = E.assign_sentences(E.split_sentences(narration), wins, cps)
            for i, (s, (a, b)) in enumerate(zip(shots, wins)):
                add_row(seg_label, seg_name, bstart + a, bstart + b,
                        s.get("desc", ""), s.get("src", ""), "".join(buckets[i]), "")

            overview.append([seg_label or blk["id"], seg_name, segs.get(seg_label, {}).get("chars", ""),
                             E.fmt_tc(bstart), E.fmt_tc(bend), round(dur, 1), narration])
        total_disp = total
    else:
        blocks, total_disp = E.estimate_timeline(segs)
        for blk, k in zip(blocks, [b["seg"] for b in blocks]):
            seg = segs[k]
            dur = blk["duration"]
            shots = E.split_visual_to_shots(seg["visual"])
            n = len(shots)
            for i, s in enumerate(shots):
                a, b = dur * i / n, dur * (i + 1) / n
                add_row(k, seg["name"], blk["start"] + a, blk["start"] + b,
                        s["desc"], s["src"], seg["narration"] if i == 0 else "",
                        "段内第 %d/%d 镜" % (i + 1, n))
            overview.append([k, seg["name"], seg["chars"], E.fmt_tc(blk["start"]),
                             E.fmt_tc(blk["end"]), round(dur, 1), seg["narration"]])

    total_chars = sum(v["chars"] for v in segs.values())

    # ---------- 写 Excel ----------
    wb = Workbook()

    # Sheet1 分镜脚本
    ws = wb.active
    ws.title = "分镜脚本"
    heads = ["镜号", "段落", "时间码（绝对）", "时长(s)", "画面内容", "素材类型",
             "素材来源", "Pexels 检索词", "解说词", "备注"]
    ws.append([doc["title"]])
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=len(heads))
    ws.cell(row=1, column=1).font = TITLE_FONT
    ws.cell(row=1, column=1).alignment = Alignment(horizontal="center", vertical="center")
    ws.row_dimensions[1].height = 26
    ws.append([])
    ws.append(heads)
    for c in range(1, len(heads) + 1):
        cell = ws.cell(row=3, column=c)
        cell.fill, cell.font, cell.alignment, cell.border = HEAD_FILL, HEAD_FONT, CENTER, BORDER
    for r in rows:
        ws.append(r)
    for i, w in enumerate([6, 20, 18, 8, 34, 11, 30, 26, 60, 14], start=1):
        ws.column_dimensions[get_column_letter(i)].width = w
    for r in range(4, 4 + len(rows)):
        for c in range(1, len(heads) + 1):
            cell = ws.cell(row=r, column=c)
            cell.border = BORDER
            cell.alignment = WRAP if c in (2, 5, 7, 8, 9, 10) else CENTER
        ws.row_dimensions[r].height = 46
    ws.freeze_panes = "A4"
    ws.auto_filter.ref = "A3:J%d" % (3 + len(rows))

    # Sheet2 段落总览
    ws2 = wb.create_sheet("段落总览")
    ws2.append([doc["title"]])
    ws2.cell(row=1, column=1).font = TITLE_FONT
    ws2.append(["解说总字数", total_chars, "成片总时长(s)", round(total_disp, 1),
                "≈", E.fmt_tc(total_disp)])
    ws2.append([])
    h2 = ["段", "段落名", "字数", "入点", "出点", "时长(s)", "解说词全文"]
    ws2.append(h2)
    for c in range(1, len(h2) + 1):
        cell = ws2.cell(row=4, column=c)
        cell.fill, cell.font, cell.alignment, cell.border = HEAD_FILL, HEAD_FONT, CENTER, BORDER
    for r in overview:
        ws2.append(r)
    for i, w in enumerate([6, 24, 8, 10, 10, 10, 90], start=1):
        ws2.column_dimensions[get_column_letter(i)].width = w
    for r in range(5, 5 + len(overview)):
        for c in range(1, len(h2) + 1):
            cell = ws2.cell(row=r, column=c)
            cell.border = BORDER
            cell.alignment = WRAP if c == 7 else CENTER
        ws2.row_dimensions[r].height = 90

    # Sheet3 音乐音效
    ws3 = wb.create_sheet("音乐音效")
    h3 = ["位置", "类型", "说明"]
    ws3.append(h3)
    for c in range(1, 4):
        cell = ws3.cell(row=1, column=c)
        cell.fill, cell.font, cell.alignment, cell.border = HEAD_FILL, HEAD_FONT, CENTER, BORDER
    for r in doc["audio"]:
        ws3.append(r)
    for i, w in enumerate([18, 12, 60], start=1):
        ws3.column_dimensions[get_column_letter(i)].width = w
    for r in range(2, 2 + len(doc["audio"])):
        for c in range(1, 4):
            ws3.cell(row=r, column=c).border = BORDER
            ws3.cell(row=r, column=c).alignment = WRAP
        ws3.row_dimensions[r].height = 30

    wb.save(out_path)

    # ---------- 自检 ----------
    agg = {}
    for r in rows:
        k = (r[1] or "").split(" ")[0]
        agg[k] = agg.get(k, "") + (r[8] or "")
    lost = [k for k in segs if agg.get(k, "") != segs[k]["narration"]]
    print("OK ->", out_path)
    print("镜头 %d 行 ｜ 段落 %d 行 ｜ 音效 %d 行 ｜ 总字数 %d ｜ 总时长 %.1fs"
          % (len(rows), len(overview), len(doc["audio"]), total_chars, total_disp))
    print("解说完整性: %s" % ("✅ 各镜头拼接与原文逐字一致" if not lost
                              else "❌ 以下段落有缺漏，需检查: %s" % " ".join(lost)))


if __name__ == "__main__":
    if len(sys.argv) < 3:
        print(__doc__)
        sys.exit(1)
    build(sys.argv[1], sys.argv[2], sys.argv[3] if len(sys.argv) > 3 else None)
