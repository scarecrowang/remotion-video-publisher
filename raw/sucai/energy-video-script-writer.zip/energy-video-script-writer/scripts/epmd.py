#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""《能源行业智能转型案例说》文稿 md 的共享解析工具。

所有脚本（count_chars / md_to_docx / build_timeline / build_shotlist_xlsx /
build_promo_docx）都从这里取解析逻辑，避免各写一份、改一处漏两处。

文稿 md 的关键锚点：
- 一级标题  `# EPxxx · 《片名》视频文稿`
- 章节      `## 1. 案例卡片` / `## 2. 宣发物料` / `## 3. 分段解说词 + 分镜表` / `## 6. 音乐音效总表`
- 宣发表    `| 标题 | … |` / `| 简介 | … |` / `| 封面图提示词 | … |`（在「宣发物料」章节下）
- 分段表    `| ① | 段落名 | 字数 | 解说词 | 画面来源/素材检索词 |`
- 音效表    `| 位置 | 类型 | 说明 |`

⚠️ 2026-09-03 变更：**片头相关的一切已移除**（原 HEAD_S / HEAD_SILENCE_S / head 时间轴块）。
无片头设计章节，时间轴从 0 秒直接进 ① 段。
"""

import io
import os
import re

# 只统计"会念出来"的字符：汉字、字母、数字、百分号、小数点
CHAR_RE = re.compile(r'[\u4e00-\u9fffA-Za-z0-9%.]')

SEG_KEYS = "①②③④⑤⑥"
SEG_NAMES = {
    "①": "标题与一句话价值",
    "②": "转型背景与痛点",
    "③": "智能化方案与技术路径",
    "④": "实施过程与关键决策",
    "⑤": "量化成效",
    "⑥": "可复制经验与启示",
}

SENT_SPLIT = re.compile(r'(?<=[。！？；])')

DEFAULT_CPS = 4.0        # 栏目语速基准（字/秒）
SEG_GAP_S = 0.5          # 段间气口
TAIL_S = 8.0             # 片尾

# 宣发物料硬上限（用户 2026-09-03 明确）
PROMO_TITLE_MAX = 20     # 标题 ≤ 20 字
PROMO_INTRO_MAX = 200    # 简介 ≤ 200 字
PROMO_KEYS = ("标题", "简介", "封面图提示词")


def count_chars(text):
    """按栏目口径统计字数：只算会念出来的字符，标点不计。"""
    return len(CHAR_RE.findall(text or ""))


def count_visible(text):
    """统计可见字符数（去空白，含标点）——宣发物料的标题/简介按此卡上限。"""
    return len(re.sub(r'\s', '', text or ""))


def parse_md(path):
    """解析文稿 md。

    返回 dict：
      title / ep / name / segs{①..⑥: {seg,name,chars,narration,visual}}
      audio[[位置,类型,说明], ...] / card{行业赛道,企业,...} / sections{章节名: 行列表}
      promo{标题, 简介, 封面图提示词}   ← 宣发物料，见 references/promo-spec.md
    """
    text = io.open(path, encoding="utf-8").read()
    lines = text.split("\n")

    # --- 按 "## " 切章节：全文捞表格会串节，必须分节处理 ---
    sections, cur, buf = {}, "", []
    for line in lines:
        if line.startswith("## "):
            if cur:
                sections[cur] = buf
            cur, buf = line.lstrip("# ").strip(), []
        else:
            buf.append(line)
    if cur:
        sections[cur] = buf

    def section(keyword):
        for k, v in sections.items():
            if keyword in k:
                return v
        return []

    # --- 标题 ---
    m = re.search(r'^#\s*EP(\d+)\s*[·\-—\s]*\s*《(.+?)》', text, re.M)
    if m:
        ep, name = m.group(1).strip(), m.group(2).strip()
        title = "EP%s · 《%s》" % (ep, name)
    else:
        ep, name = "", ""
        title = lines[0].lstrip("# ").strip() if lines else ""

    # --- 案例卡片（| 字段 | 内容 |） ---
    card = {}
    for line in section("案例卡片"):
        s = line.strip()
        if not s.startswith("|"):
            continue
        cells = [c.strip() for c in s.strip("|").split("|")]
        if len(cells) == 2 and cells[0] not in ("字段", "---"):
            card[cells[0]] = cells[1]

    # --- 分段解说词（| ① | 段落名 | 字数 | 解说词 | 画面来源 |） ---
    segs = {}
    for line in section("分段解说词") or lines:
        m = re.match(r'^\|\s*([①②③④⑤⑥])\s*\|', line.strip())
        if not m:
            continue
        cells = [c.strip() for c in line.strip().strip("|").split("|")]
        if len(cells) < 5:
            continue
        narration = cells[3].replace("<br>", " ")
        segs[m.group(1)] = {
            "seg": m.group(1),
            "name": cells[1] or SEG_NAMES.get(m.group(1), ""),
            "chars": count_chars(narration),
            "narration": narration,
            "visual": cells[4],
        }

    # --- 宣发物料（| 项 | 内容 |，在「宣发物料」章节下）---
    promo = {k: "" for k in PROMO_KEYS}
    for line in section("宣发物料"):
        s = line.strip()
        if not s.startswith("|"):
            continue
        cells = [c.strip() for c in s.strip("|").split("|")]
        if len(cells) == 2 and cells[0] not in ("项", "---"):
            for k in PROMO_KEYS:
                if k in cells[0]:
                    promo[k] = cells[1]

    # --- 音乐音效总表（| 位置 | 类型 | 说明 |） ---
    audio = []
    for line in section("音乐音效"):
        s = line.strip()
        if not s.startswith("|"):
            continue
        cells = [c.strip() for c in s.strip("|").split("|")]
        if len(cells) == 3 and cells[0] not in ("位置", "---"):
            audio.append(cells)

    return {
        "title": title, "ep": ep, "name": name,
        "segs": segs, "audio": audio, "card": card, "promo": promo,
        "sections": sections, "path": path,
    }


# ---------- 句子 / 镜头工具 ----------

def split_sentences(text):
    parts = [p for p in SENT_SPLIT.split(text or "") if p.strip()]
    return [p.strip() for p in parts] or ([text] if text else [])


def fmt_tc(sec):
    sec = max(0.0, float(sec))
    return "%02d:%04.1f" % (int(sec // 60), sec % 60)


def parse_rel_window(t, seg_dur):
    """'0–6s' / '0-6s' / '6s' -> (start, end)，超出段长时按比例缩放。"""
    t = (t or "").replace("秒", "").replace("s", "").strip()
    nums = re.findall(r'[\d.]+', t)
    if len(nums) >= 2:
        a, b = float(nums[0]), float(nums[1])
    elif len(nums) == 1:
        a, b = 0.0, float(nums[0])
    else:
        a, b = 0.0, seg_dur
    if b > seg_dur > 0:
        k = seg_dur / b
        a, b = a * k, b * k
    return a, min(b, seg_dur) if seg_dur > 0 else b


def classify(src):
    s = src or ""
    if "官媒" in s or "央视" in s or "新华社" in s or "人民日报" in s:
        return "官媒实拍"
    if "自制" in s or "动效" in s or "数据卡" in s or "字幕" in s:
        return "自制/动效"
    if "Pexels" in s or "Pixabay" in s:
        return "图库素材"
    return "待定"


def split_src(src):
    """拆出「素材来源」与「图库检索词」两列。"""
    official, stock = [], []
    for p in re.split(r'[｜|]', src or ""):
        p = p.strip()
        if not p:
            continue
        if re.search(r'Pexels|Pixabay', p, re.I):
            q = re.sub(r'^\s*(Pexels|Pixabay)\s*[:：]\s*', '', p, flags=re.I)
            q = " / ".join(x.strip() for x in re.split(r'[＋+]', q)
                           if x.strip() and "自制" not in x)
            stock.append(q)
        else:
            official.append(p)
    return " ｜ ".join(official), " / ".join(x for x in stock if x)


def assign_sentences(sents, wins, cps=None):
    """把解说句切成与镜头数相同的片段。

    策略：按各镜头累计时长占比算理想切分字数 → 吸附到最近句子边界。
    三条硬约束：(a) 句子不丢不乱序 (b) 断点尽量贴镜头边界 (c) 每个镜头至少 1 句（句数够时）。

    ⚠️ 历史坑位（改这里前先读）：
    - 切点必须取 wins[:-1] 的结束时间；写成 wins[1:] 会让解说与画面整体错位一格。
    - 吸附必须给后续镜头预留句子（hi = n_sent - 剩余镜头数），否则长句会把
      后面所有句子挤到最后一个镜头，末尾镜头塞满、中间镜头全空。
    """
    n_shot = len(wins)
    if n_shot <= 1 or not sents:
        return [sents] + [[] for _ in range(max(0, n_shot - 1))]
    lens = [count_chars(s) for s in sents]
    total = sum(lens) or 1
    cum = [0]
    for L in lens:
        cum.append(cum[-1] + L)
    span = wins[-1][1] or 1
    cuts = [round(total * (w[1] / span)) for w in wins[:-1]]
    bounds, last, n_sent = [], 0, len(sents)
    for k, c in enumerate(cuts):
        lo = last + 1
        hi = n_sent - (n_shot - 1 - k)
        best, bestd = None, None
        for j in range(lo, max(lo, hi) + 1):
            d = abs(cum[j] - c)
            if bestd is None or d < bestd:
                best, bestd = j, d
        if best is None:
            best = min(max(lo, n_sent), n_sent)
        bounds.append(best)
        last = best
    idxs = [0] + bounds + [n_sent]
    return [sents[idxs[i]:idxs[i + 1]] for i in range(n_shot)]


def split_visual_to_shots(visual):
    """无时间轴 JSON 时，把 md 的「画面来源」列拆成多个镜头描述。"""
    parts = re.split(r'[；;]|\s{2,}|(?<=[。）])\s*\+', visual or "")
    shots = []
    for p in parts:
        p = p.strip()
        if not p:
            continue
        shots.append({"t": "", "desc": re.split(r'[/｜|]', p)[0].strip(), "src": p})
    return shots or [{"t": "", "desc": visual or "", "src": visual or ""}]


def estimate_timeline(segs, cps=DEFAULT_CPS, gap=SEG_GAP_S, tail=TAIL_S):
    """按字数估算各段绝对入出点。返回 (blocks, total)。

    blocks 里每段含 start/end/duration，可直接写进时间轴 JSON。
    无片头，时间轴从 0 秒直接进 ① 段。
    """
    blocks, cursor = [], 0.0
    for k in SEG_KEYS:
        if k not in segs:
            continue
        seg = segs[k]
        dur = seg["chars"] / float(cps or DEFAULT_CPS)
        blocks.append({
            "id": "S%d" % (len(blocks) + 1), "seg": k, "name": seg["name"],
            "start": round(cursor, 2), "end": round(cursor + dur, 2),
            "duration": round(dur, 2), "narration": None, "shots": [],
        })
        cursor += dur + gap
    total = round(cursor - gap + tail, 2) if blocks else round(tail, 2)
    return blocks, total
