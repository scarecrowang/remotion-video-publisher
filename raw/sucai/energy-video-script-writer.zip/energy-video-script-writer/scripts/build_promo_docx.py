#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""把文稿里的**宣发物料**（标题 / 简介 / 封面图）排版成 Word。

【默认交付物】每期必出，与 `EPxxx-片名-视频文稿.md` 并列。
规范见 `references/promo-spec.md`：标题 ≤20 字、简介 ≤200 字、封面图 16:9 横版高清。

用法:
    python build_promo_docx.py <文稿.md> <输出.docx> [封面原图] [选项]

参数:
    封面原图           可省略。省略时在同目录自动找 *封面*/cover 图片。
                       ImageGen 出图多为 1536x1024（3:2），本脚本会**居中裁成 16:9**
                       并存一份 `EPxxx-封面-16x9.png` 在 docx 同目录，再嵌入 Word。
选项:
    --width 1920       裁后封面图宽（像素）。默认 1920，高按 16:9 自动算（1080）
    --force            标题/简介超字数时仍生成（默认直接报错退出）

依赖：python-docx、Pillow（托管 venv 已装）。
解析逻辑共用 epmd.py：宣发物料写在 md 的「## 2. 宣发物料」章节下，
用 `| 标题 | … |` / `| 简介 | … |` / `| 封面图提示词 | … |` 两列表格。
"""

import glob
import io
import os
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import epmd as E                                                    # noqa: E402

from docx import Document                                           # noqa: E402
from docx.enum.text import WD_ALIGN_PARAGRAPH                       # noqa: E402
from docx.shared import Cm, Pt, RGBColor                            # noqa: E402

IMG_EXT = ("*.png", "*.jpg", "*.jpeg", "*.webp", "*.PNG", "*.JPG", "*.JPEG")
ACCENT = RGBColor(0x0B, 0x5F, 0xA5)
GRAY = RGBColor(0x77, 0x77, 0x77)


def find_cover(md_path, out_path, given=None):
    """定位封面原图：显式给定 > docx 同目录 / md 同目录里的 *封面*|cover 图片。"""
    if given:
        if not os.path.exists(given):
            print("❌ 找不到封面图:", given)
            sys.exit(1)
        return given
    dups = [os.path.dirname(os.path.abspath(out_path)),
            os.path.dirname(os.path.abspath(md_path))]
    seen = set()
    for d in dups:
        if d in seen:
            continue
        seen.add(d)
        for ext in IMG_EXT:
            for p in sorted(glob.glob(os.path.join(d, ext))):
                b = os.path.basename(p)
                if re.search(r'封面|cover|16x9', b, re.I) and "16x9" not in b:
                    return p
    return None


def crop_169(src, out_path, width=1920):
    """把任意比例的图片居中裁成 16:9，缩放到指定宽度。返回 (落盘路径, 宽, 高)。"""
    from PIL import Image
    im = Image.open(src)
    if im.mode in ("RGBA", "P", "LA"):
        im = im.convert("RGB")
    w, h = im.size
    target_h = int(round(width * 9 / 16))
    # 居中裁到最接近的 16:9 区域（只裁不拉伸，避免变形）
    if w / float(h) > 16 / 9.0:          # 太宽 → 裁左右
        nw = int(round(h * 16 / 9.0))
        box = ((w - nw) // 2, 0, (w - nw) // 2 + nw, h)
    else:                                 # 太高 → 裁上下
        nh = int(round(w * 9 / 16.0))
        box = (0, (h - nh) // 2, w, (h - nh) // 2 + nh)
    im = im.crop(box)
    if im.size[0] != width:
        im = im.resize((width, target_h), Image.LANCZOS)
    im.save(out_path, "PNG")
    return out_path, width, target_h


def check_promo(promo, force=False):
    """字数卡口：标题 ≤20、简介 ≤200。返回是否通过。"""
    title, intro = promo.get("标题", ""), promo.get("简介", "")
    nt, ni = E.count_visible(title), E.count_visible(intro)
    ok = True
    print("宣发字数  标题 %d/%d ｜ 简介 %d/%d" %
          (nt, E.PROMO_TITLE_MAX, ni, E.PROMO_INTRO_MAX))
    if not title or not intro:
        print("❌ 宣发物料缺失：md 的「宣发物料」章节必须有 标题 / 简介 两行")
        ok = False
    if nt > E.PROMO_TITLE_MAX:
        print("❌ 标题 %d 字，超上限 %d 字（需删 %d 字）" % (nt, E.PROMO_TITLE_MAX, nt - E.PROMO_TITLE_MAX))
        ok = False
    if ni > E.PROMO_INTRO_MAX:
        print("❌ 简介 %d 字，超上限 %d 字（需删 %d 字）" % (ni, E.PROMO_INTRO_MAX, ni - E.PROMO_INTRO_MAX))
        ok = False
    if ok:
        print("✅ 字数合规")
    elif not force:
        print("未生成 docx。改完 md 再跑，或加 --force 强行生成。")
    return ok


def build(md_path, out_path, cover=None, width=1920, force=False):
    doc_md = E.parse_md(md_path)
    promo = doc_md["promo"]
    if not check_promo(promo, force=force) and not force:
        sys.exit(1)

    src = find_cover(md_path, out_path, cover)
    cover_169 = None
    if src:
        stem = ("EP%s" % doc_md["ep"]) if doc_md["ep"] else \
            os.path.splitext(os.path.basename(out_path))[0]
        cover_169 = os.path.join(os.path.dirname(os.path.abspath(out_path)),
                                 "%s-封面-16x9.png" % stem)
        cover_169, cw, ch = crop_169(src, cover_169, width)
        print("封面 %s → 16:9 裁切 %dx%d -> %s" % (os.path.basename(src), cw, ch, cover_169))
    else:
        print("⚠️ 没找到封面图，将只排版标题 + 简介（补图后重跑即可）")

    # ---------- 排版 ----------
    d = Document()
    sec = d.sections[0]
    sec.page_width, sec.page_height = Cm(21.0), Cm(29.7)
    sec.left_margin = sec.right_margin = Cm(2.0)
    sec.top_margin = sec.bottom_margin = Cm(1.8)
    content_w = 21.0 - 4.0                      # 17cm
    style = d.styles["Normal"]
    style.font.name = "Microsoft YaHei"
    style.font.size = Pt(10.5)

    def para(text, size=10.5, bold=False, color=None, align=None,
             space_before=0, space_after=6, line=1.5):
        p = d.add_paragraph()
        r = p.add_run(text)
        r.font.size, r.bold = Pt(size), bold
        if color is not None:
            r.font.color.rgb = color
        if align is not None:
            p.alignment = align
        p.paragraph_format.space_before = Pt(space_before)
        p.paragraph_format.space_after = Pt(space_after)
        p.paragraph_format.line_spacing = line
        return p

    # 页眉：栏目名 + EP 号
    hdr = sec.header.paragraphs[0]
    hdr.text = "《能源行业智能转型案例说》· %s" % (doc_md["title"] or "")
    hdr.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    for r in hdr.runs:
        r.font.size, r.font.color.rgb = Pt(8.5), GRAY

    if cover_169:
        d.add_paragraph().add_run().add_picture(
            cover_169, width=Cm(content_w), height=Cm(content_w * 9 / 16.0))

    para(promo.get("标题", ""), size=20, bold=True, color=ACCENT,
         align=WD_ALIGN_PARAGRAPH.CENTER, space_before=10, space_after=4, line=1.3)
    para(promo.get("简介", ""), size=11, align=WD_ALIGN_PARAGRAPH.LEFT,
         space_before=2, space_after=14, line=1.7)

    # 元信息：方便终审核对
    card = doc_md["card"]
    meta = " ｜ ".join(x for x in [
        ("EP%s" % doc_md["ep"]) if doc_md["ep"] else "",
        card.get("企业", ""), card.get("行业赛道", ""), card.get("核心技术", "")] if x)
    if meta:
        para(meta, size=9, color=GRAY, align=WD_ALIGN_PARAGRAPH.LEFT, space_after=2, line=1.2)
    if promo.get("封面图提示词"):
        para("封面图提示词：" + promo["封面图提示词"], size=8.5, color=GRAY,
             align=WD_ALIGN_PARAGRAPH.LEFT, space_after=0, line=1.2)

    d.save(out_path)
    print("OK ->", out_path, "(%d 字节)" % os.path.getsize(out_path))
    if cover_169:
        print("封面 16:9 ->", cover_169)


def main():
    argv = sys.argv[1:]
    opts = {a for a in argv if a.startswith("--")}
    force = "--force" in opts
    width = 1920
    pos, i = [], 0
    while i < len(argv):
        a = argv[i]
        if a == "--width" and i + 1 < len(argv):
            width = int(argv[i + 1]); i += 2; continue
        if not a.startswith("--"):
            pos.append(a)
        i += 1
    if len(pos) < 2:
        print(__doc__)
        sys.exit(1)
    build(pos[0], pos[1], pos[2] if len(pos) > 2 else None,
          width=width, force=force)


if __name__ == "__main__":
    main()
