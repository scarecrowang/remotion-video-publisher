#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""从文稿 md 生成 **时间轴工程 JSON** 骨架（各段绝对入出点）。

【按需产物】默认不生成；用户明确要「时间轴 / 工程文件 / 剪辑对轨」时才跑。
产出物可直接喂 OpenMontage / moviepy / Remotion；也是 build_shotlist_xlsx.py
逐镜头拆分的输入（没有它就只能按段落估算）。

⚠️ 本栏目**不做片头**（2026-09-03 起）：时间轴从 0 秒直接进 ① 段，无 head 块。

用法:
    python build_timeline.py <文稿.md> <输出.json> [选项]

选项:
    --cps 4.0           语速（字/秒），用户回传实测配音时长后改这里重算
    --gap 0.5           段间气口（秒）
    --tail 8.0          片尾（秒）
    --voice 音色名      仅作提示写入，不产出音频

▶ 重复运行会**保留已填好的 shots**（按 id 匹配），可以放心在改完文案后重算时间码。
"""

import io
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import epmd as E                                                    # noqa: E402


def main():
    argv = sys.argv[1:]
    if len(argv) < 2:
        print(__doc__); sys.exit(1)
    md_path, out_path = argv[0], argv[1]

    opt = {
        "--cps": E.DEFAULT_CPS, "--gap": E.SEG_GAP_S,
        "--tail": E.TAIL_S, "--voice": "",
    }
    i = 2
    while i < len(argv):
        k = argv[i]
        if k in opt and i + 1 < len(argv):
            opt[k] = float(argv[i + 1]) if k != "--voice" else argv[i + 1]
            i += 2
        else:
            i += 1

    cps = float(opt["--cps"])
    tail_s = float(opt["--tail"])

    doc = E.parse_md(md_path)
    segs = doc["segs"]
    if not segs:
        print("❌ 没解析到分段解说词表。"); sys.exit(1)

    # 旧文件的 shots 要保住（按 id 匹配），避免重算时间码把填好的分镜冲掉
    old = {}
    if os.path.exists(out_path):
        try:
            o = json.load(io.open(out_path, encoding="utf-8"))
            for b in o.get("timeline", []):
                old[b.get("id") or b.get("seg", "")] = b.get("shots") or []
        except Exception as e:
            print("⚠️ 旧时间轴读取失败，将重建：%s" % e)

    blocks, total = E.estimate_timeline(
        segs, cps=cps, gap=float(opt["--gap"]), tail=tail_s)

    for b in blocks:
        b["shots"] = old.get(b["id"], [])

    last_end = blocks[-1]["end"] if blocks else 0.0
    tail = {"id": "tail", "name": "片尾", "start": round(last_end, 2),
            "end": round(last_end + tail_s, 2), "duration": round(tail_s, 2),
            "narration": None, "shots": old.get("tail", [])}

    data = {
        "episode": ("EP%s" % doc["ep"]) if doc["ep"] else "",
        "title": doc["name"] or doc["title"],
        "company": doc["card"].get("企业", ""),
        "track": doc["card"].get("行业赛道", ""),
        "cps": cps,
        "gap_between_segments_s": float(opt["--gap"]),
        "tail_s": tail_s,
        "chars_total": sum(v["chars"] for v in segs.values()),
        "total_duration_s": total,
        "over_300s_by": round(total - 300.0, 1),
        "voice_note": {
            "音色": opt["--voice"] or "zh-CN-YunyangNeural（建议，男声·沉稳理性）",
            "语速": "%.1f 字/秒" % cps,
            "说明": "不产出音频文件，配音由用户自理；若拿到实测时长请回填 cps 后重跑本脚本",
        },
        "timeline": blocks + [tail],
    }

    with io.open(out_path, "w", encoding="utf-8") as f:
        f.write(json.dumps(data, ensure_ascii=False, indent=2))

    filled = sum(1 for b in data["timeline"] if b["shots"])
    print("OK ->", out_path)
    print("解说段 %d 段 ｜ 片尾 %.1fs ｜ 成片 %.1fs（%d 分 %02d 秒）"
          % (len(blocks), tail_s, total, int(total // 60), int(total % 60)))
    print("总字数 %d ｜ 语速 %.2f 字/秒" % (data["chars_total"], cps))
    print("已填分镜 %d/%d 段 —— shots 为空的段在 xlsx 里会标记「镜头待细分」"
          % (filled, len(data["timeline"])))
    if total > 300:
        print("⚠️ 超 300s 目标 %.1fs，压缩方案见 references/preproduction.md" % (total - 300))


if __name__ == "__main__":
    main()
