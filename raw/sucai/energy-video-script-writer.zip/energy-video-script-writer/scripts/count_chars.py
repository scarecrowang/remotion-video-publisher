#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""字数复核 —— 文稿定稿前必跑。

初稿目测普遍偏少 100 字左右，必须实算才算数。
计数口径：`[\\u4e00-\\u9fffA-Za-z0-9%.]`（只算会念出来的字符，标点不计）。

用法:
    python count_chars.py <文稿.md> [--cps 4.0] [--strict]

- 合格区间 1150–1200 字；`--strict` 时不合格以退出码 1 结束（便于脚本化卡口）。
- 同时打印各段秒数与成片估算时长。
"""

import io
import os
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import epmd as E                                                    # noqa: E402

MIN_CHARS, MAX_CHARS = 1150, 1200


def main():
    args = [a for a in sys.argv[1:]]
    cps = E.DEFAULT_CPS
    strict = False
    md = None
    i = 0
    while i < len(args):
        a = args[i]
        if a == "--cps" and i + 1 < len(args):
            cps = float(args[i + 1]); i += 2
        elif a == "--strict":
            strict = True; i += 1
        elif not a.startswith("-"):
            md = a; i += 1
        else:
            i += 1
    if not md:
        print(__doc__); sys.exit(1)

    doc = E.parse_md(md)
    segs = doc["segs"]
    if not segs:
        print("❌ 没解析到分段解说词表，检查 md 是否用了「## 3. 分段解说词 + 分镜表」章节与 | ① | 开头。")
        sys.exit(1)

    total = 0
    print("段  字数    秒数(÷%.2f)   段落名" % cps)
    print("-" * 56)
    for k in E.SEG_KEYS:
        if k not in segs:
            print("%s  ⚠️ 缺失" % k)
            continue
        n = segs[k]["chars"]
        total += n
        flag = "" if n > 0 else "  ⚠️ 空"
        print("%s  %4d    %6.1fs   %s%s" % (k, n, n / cps, segs[k]["name"], flag))

    narr = total / cps
    gaps = E.SEG_GAP_S * (len(segs) - 1)
    film = narr + gaps + E.TAIL_S
    print("-" * 56)
    print("解说总字数 %d ｜ 解说 %.1fs + 气口 %.1fs + 片尾 %.1fs"
          % (total, narr, gaps, E.TAIL_S))
    print("成片估算 %.1fs ≈ %d 分 %02d 秒" % (film, int(film // 60), int(film % 60)))

    ok = MIN_CHARS <= total <= MAX_CHARS
    if ok:
        print("✅ 字数 %d 落在 %d–%d 合格区间" % (total, MIN_CHARS, MAX_CHARS))
    else:
        delta = total - MAX_CHARS if total > MAX_CHARS else total - MIN_CHARS
        print("❌ 字数 %d，%s %d 字才进 %d–%d 区间"
              % (total, "需删" if total > MAX_CHARS else "需补", abs(delta), MIN_CHARS, MAX_CHARS))
    sys.exit(0 if (ok or not strict) else 1)


if __name__ == "__main__":
    main()
