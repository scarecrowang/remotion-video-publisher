#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""文稿 Markdown → Word（.docx）。

【按需产物】默认不生成；用户明确要「docx / Word / 给领导看的文档」时才跑。
链路：md →（内置转换器）→ HTML →（tencent-docx 的 html_to_docx）→ docx

用法:
    python md_to_docx.py <文稿.md> <输出.docx> [--keep-html]

环境（可移植）：
- HTML→DOCX 依赖 tencent-docx 插件的 html_to_docx，跑在独立 venv 里。
- 两个路径均支持环境变量覆盖，未设置时回退到 WorkBuddy 默认位置（home 目录展开，不写死用户名）：
  - `TENCENT_DOCX_PLUGIN`   → tencent-docx 插件目录
  - `HTML_TO_DOCX_PY`       → 装了 html_to_docx 的 python 解释器
- venv 不存在时会自动执行插件自带的 setup 脚本（幂等）。
- ⚠️ 本脚本是【按需产物】，依赖 WorkBuddy 的 tencent-docx 插件；在其他 agent 里若无此插件则不可用，
  但不影响核心工作流（核心交付是 md 文稿 + 宣发 Word，后者只依赖 python-docx/Pillow）。
"""

import glob
import io
import os
import re
import subprocess
import sys
import tempfile


def _home(p):
    """展开 ~ 且不写死用户名，让脚本可移植。"""
    return os.path.expanduser(p)


PLUGIN_ROOT = os.environ.get("TENCENT_DOCX_PLUGIN") or \
    _home("~/.workbuddy/plugins/cache/workbuddy-builtin/tencent-docx")
VENV_PY = os.environ.get("HTML_TO_DOCX_PY") or \
    _home("~/.venv-html-to-docx/bin/python")

CSS = """
@page { @bottom-center { content: counter(page) " / " counter(pages); } }
body { font-family: "Microsoft YaHei", "PingFang SC", "Heiti SC", sans-serif;
       font-size: 10.5pt; line-height: 1.7; }
h1 { font-size: 20pt; text-align: center; color: #1a1a1a; }
h2 { font-size: 14pt; color: #0b5fa5; border-bottom: 1px solid #d0d7de;
     padding-bottom: 3px; margin-top: 16px; }
h3 { font-size: 12pt; color: #333; }
table { border-collapse: collapse; width: 100%; margin: 6px 0; font-size: 9.5pt; }
th, td { border: 1px solid #999; padding: 4px 6px; vertical-align: top; }
th { background: #eef4fa; font-weight: bold; }
blockquote { border-left: 3px solid #0b5fa5; background: #f5f8fb;
             padding: 5px 10px; color: #444; margin: 6px 0; }
code { font-family: Consolas, "Courier New", monospace; font-size: 9.5pt; }
ul, ol { margin: 4px 0 4px 18px; }
p { margin: 4px 0; }
"""

BLOCK_START = re.compile(r'^(#{1,3}\s|>|\||[-*]\s|\d+\.\s|---)')


def inline(t):
    t = (t or "").replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    t = re.sub(r'\*\*(.+?)\*\*', r'<strong>\1</strong>', t)
    t = re.sub(r'`(.+?)`', r'<code>\1</code>', t)
    t = re.sub(r'\[(.+?)\]\((.+?)\)', r'<a href="\2">\1</a>', t)
    return t


def md_to_html(md_path, title=""):
    """极简 md → html。够用就好：标题 / 表格 / 有序无序列表 / 引用 / 分隔线 / 段落。"""
    lines = io.open(md_path, encoding="utf-8").read().split("\n")
    body, i, n = [], 0, len(lines)
    while i < n:
        line, s = lines[i].rstrip(), lines[i].strip()
        if not s:
            i += 1; continue

        # 表格：当前行以 | 开头，且下一行是分隔行
        if s.startswith("|") and i + 1 < n and re.match(r'^\|[\s:|-]+\|$', lines[i + 1].strip()):
            rows = []
            while i < n and lines[i].strip().startswith("|"):
                rows.append(lines[i].strip()); i += 1
            cells = [[c.strip() for c in r.strip("|").split("|")]
                     for k, r in enumerate(rows) if k != 1]
            if cells:
                body.append("<table><thead><tr>%s</tr></thead><tbody>%s</tbody></table>" % (
                    "".join("<th>%s</th>" % inline(c) for c in cells[0]),
                    "".join("<tr>%s</tr>" % "".join("<td>%s</td>" % inline(c) for c in r)
                            for r in cells[1:])))
            continue

        if s.startswith("### "):
            body.append("<h3>%s</h3>" % inline(s[4:])); i += 1; continue
        if s.startswith("## "):
            body.append("<h2>%s</h2>" % inline(s[3:])); i += 1; continue
        if s.startswith("# "):
            body.append("<h1>%s</h1>" % inline(s[2:])); i += 1; continue
        if s.startswith("---"):
            body.append("<hr/>"); i += 1; continue

        if s.startswith("> "):
            buf = []
            while i < n and (lines[i].strip().startswith("> ") or lines[i].strip() == ">"):
                buf.append(lines[i].strip().lstrip(">").strip()); i += 1
            body.append("<blockquote>%s</blockquote>" % "<br/>".join(inline(x) for x in buf))
            continue

        if re.match(r'^[-*]\s', s):
            body.append("<ul>")
            while i < n and re.match(r'^[-*]\s', lines[i].strip()):
                item = re.sub(r'^[-*]\s', "", lines[i].strip()); i += 1
                sub = []
                while i < n and re.match(r'^\s{2,}[-*]\s', lines[i]):
                    sub.append(re.sub(r'^\s*[-*]\s', "", lines[i].strip())); i += 1
                body.append("<li>%s%s</li>" % (
                    inline(item),
                    "<ul>%s</ul>" % "".join("<li>%s</li>" % inline(x) for x in sub) if sub else ""))
            body.append("</ul>")
            continue

        if re.match(r'^\d+\.\s', s):
            body.append("<ol>")
            while i < n and re.match(r'^\d+\.\s', lines[i].strip()):
                body.append("<li>%s</li>" % inline(re.sub(r'^\d+\.\s', "", lines[i].strip()))); i += 1
            body.append("</ol>")
            continue

        buf = []
        while i < n and lines[i].strip() and not BLOCK_START.match(lines[i].strip()):
            buf.append(lines[i].strip()); i += 1
        if buf:
            body.append("<p>%s</p>" % "<br/>".join(inline(x) for x in buf))
        else:
            i += 1

    return ("<!DOCTYPE html><html><head><meta charset=\"utf-8\">"
            "<title>%s</title><style>%s</style></head><body>\n%s\n</body></html>"
            % (inline(title), CSS, "\n".join(body)))


def find_plugin():
    """定位 tencent-docx 插件目录，取版本号最高的那个（不写死版本）。"""
    def key(p):
        m = re.findall(r'\d+', os.path.basename(p))
        return tuple(int(x) for x in m) if m else (0,)
    cands = [p for p in glob.glob(os.path.join(PLUGIN_ROOT, "*")) if os.path.isdir(p)]
    return sorted(cands, key=key)[-1] if cands else None


def ensure_venv(plugin):
    if os.path.exists(VENV_PY):
        return True
    setup = os.path.join(plugin, "scripts", "wb", "local", "setup-html-to-docx.sh")
    if not os.path.exists(setup):
        print("❌ 找不到 venv(%s) 也找不到安装脚本(%s)" % (VENV_PY, setup)); return False
    print("⏳ 首次使用，正在准备 html-to-docx 环境…")
    r = subprocess.run(["bash", setup], capture_output=True, text=True)
    if r.returncode != 0:
        print("❌ 环境准备失败:\n%s" % r.stdout[-1500:]); return False
    return os.path.exists(VENV_PY)


def main():
    args = sys.argv[1:]
    keep_html = "--keep-html" in args
    args = [a for a in args if not a.startswith("--")]
    if len(args) < 2:
        print(__doc__); sys.exit(1)
    md_path, out_path = args[0], args[1]
    if not os.path.exists(md_path):
        print("❌ 找不到输入文件:", md_path); sys.exit(1)

    plugin = find_plugin()
    if not plugin:
        print("❌ 未找到 tencent-docx 插件，检查:", PLUGIN_ROOT); sys.exit(1)
    if not ensure_venv(plugin):
        sys.exit(1)

    title = os.path.splitext(os.path.basename(md_path))[0]
    html_path = os.path.splitext(out_path)[0] + ".html" if keep_html else \
        os.path.join(tempfile.gettempdir(), "wb_" + os.path.basename(os.path.splitext(out_path)[0]) + ".html")
    io.open(html_path, "w", encoding="utf-8").write(md_to_html(md_path, title))
    print("md → html  OK (%d 字节)" % os.path.getsize(html_path))

    env = dict(os.environ, PYTHONPATH=os.path.join(plugin, "skills", "html-to-docx", "scripts"))
    r = subprocess.run([VENV_PY, "-m", "html_to_docx", "convert", html_path, "-o", out_path],
                       capture_output=True, text=True, env=env)
    if r.returncode != 0 or not os.path.exists(out_path):
        print("❌ html → docx 失败:\n%s\n%s" % (r.stdout[-1200:], r.stderr[-1200:])); sys.exit(1)

    # 校验：确认段落/表格没丢（python-docx 在同一个 venv 里）
    chk = VENV_PY + ' -c "import docx;d=docx.Document(r\'%s\');print(len(d.paragraphs),len(d.tables))"' % out_path
    v = subprocess.run(chk, shell=True, capture_output=True, text=True)
    print("html → docx OK ->", out_path, "(%d 字节)" % os.path.getsize(out_path))
    if v.returncode == 0:
        p, t = v.stdout.split()
        print("校验：段落 %s ｜ 表格 %s %s" % (p, t, "✅" if int(t) > 0 else "⚠️ 没抓到表格，检查 md 表格格式"))
    if not keep_html:
        os.remove(html_path)


if __name__ == "__main__":
    main()
