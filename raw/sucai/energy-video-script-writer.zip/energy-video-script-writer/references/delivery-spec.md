# 交付物规范 · 《能源行业智能转型案例说》

> 用户 2026-09-03 明确：**每期默认交付 md 文稿 + 宣发物料 Word 两份**，其余一律按需。
> 历史口径（2026-09-02 的「docx + xlsx 双件套必交」）**已作废**，以本文件为准。

## 一、交付物矩阵

| 交付物 | 类型 | 何时产出 | 生成方式 |
|---|---|---|---|
| `EPxxx-片名-视频文稿.md` | **默认** | 每期必出，主交付物 | 按 `assets/skeleton.md` 手写/填充 |
| `EPxxx-片名-宣发物料.docx` | **默认** | 每期必出：标题 + 简介 + 封面图 | `scripts/build_promo_docx.py` |
| `EPxxx-封面-16x9.png` | **默认** | 随宣发 Word 产出，可直接发布用 | 同上脚本裁切生成 |
| `EPxxx-片名-视频文稿.docx` | 按需 | 用户要「文稿 Word / docx / 给领导评审的文档」 | `scripts/md_to_docx.py` |
| `EPxxx-片名-视频脚本.xlsx` | 按需 | 用户要「脚本表 / 分镜表 / Excel / 剪辑用的表」 | `scripts/build_shotlist_xlsx.py` |
| `EPxxx-素材/EPxxx-时间轴工程.json` | 按需 | 用户要「时间轴 / 工程文件 / 剪辑对轨」 | `scripts/build_timeline.py` |
| `EPxxx-素材/EPxxx-素材归集清单.md` | 按需 | 用户要「素材清单 / 去哪找画面」 | 按 `assets/storyboard.template.md` 填 |

**判断原则**：md + 宣发 Word 两份打包交付；其余四个**别自作主张全生成一遍**——
用户明确说过不要。拿不准就在回复里补一句「需要文稿 Word / 脚本表 / 时间轴的话我再补」。

⚠️ **封面图走 ImageGen，每次约 5–10 积分，出图前必须告知用户。**

## 二、硬约束（与交付物无关，任何时候都生效）

- **不生成任何音频文件**（mp3/wav/m4a…）。配音由用户自理，AI 只给音色/语速建议。
- **不做片头**（2026-09-03 起）：无片头设计章节、无片头时长约束，时间轴从 0 秒直进 ① 段。
- **不代下版权视频**。官媒画面由用户人工归集，AI 只出检索关键词。
- **工作流：先出文稿 → 用户确认 → 再进视频生成。** 确认环节不得跳过。
- 宣发标题 ≤ 20 字、简介 ≤ 200 字（脚本卡口，超限报错）。
- 地图必须用标准底图、国界线完整。

## 三、命令速查

统一变量（复制即用，先装依赖 `pip install -r requirements.txt`）：

```bash
S=<本技能目录>/scripts        # 技能装好后所在的 scripts 子目录
PY=python3                    # 环境 python3
```

**生成宣发物料 Word**（标题 + 简介 + 16:9 封面图，默认交付）：

```bash
# 先用 ImageGen 出图（消耗额度！）：size="1536x1024" quality="high"
"$PY" "$S/build_promo_docx.py" "EP001-自驱电网-视频文稿.md" \
      "EP001-自驱电网-宣发物料.docx" "EP001-封面.png"
```

**字数复核**（定稿前必跑，目测普遍偏少 100 字）：

```bash
"$PY" "$S/count_chars.py" "EP001-自驱电网-视频文稿.md"        # 加 --strict 可卡退出码
```

**文稿 md → docx**：

```bash
"$PY" "$S/md_to_docx.py" "EP001-自驱电网-视频文稿.md" "EP001-自驱电网-视频文稿.docx"
```

**生成时间轴工程 JSON**（各段绝对入出点）：

```bash
"$PY" "$S/build_timeline.py" "EP001-自驱电网-视频文稿.md" \
      "EP001-素材/EP001-时间轴工程.json" --cps 4.0
```

**生成 Excel 分镜脚本表**（喂时间轴可逐镜头，不喂则按段估算）：

```bash
"$PY" "$S/build_shotlist_xlsx.py" "EP001-自驱电网-视频文稿.md" \
      "EP001-自驱电网-视频脚本.xlsx" "EP001-素材/EP001-时间轴工程.json"
```

## 四、产物依赖链

```
文稿.md ──┬─→ count_chars.py        字数/时长校验
          ├─→ build_promo_docx.py   → 宣发物料.docx + 封面-16x9.png（默认交付）
          ├─→ md_to_docx.py         → 文稿全文.docx
          ├─→ build_timeline.py     → 时间轴工程.json
          │                              ↓（填 shots）
          └─→ build_shotlist_xlsx.py ─→ .xlsx（有 JSON 逐镜头，无 JSON 按段估算）
```

宣发物料依赖链：`文稿.md` 的「宣发物料」章节 →（ImageGen 出封面）→ `build_promo_docx.py`。
第三个参数（封面原图）可省略，脚本会在 docx / md 同目录自动找名字带 `封面` / `cover` 的图。

`build_timeline.py` 重复运行**会保留已填好的 shots**（按 id 匹配），
所以改完文案可以放心重算时间码，不会冲掉分镜。

## 五、环境依赖

依赖统一由 `requirements.txt` 声明，首次使用前 `pip install -r requirements.txt` 即可。

| 依赖 | 用途 | 是否核心 |
|---|---|---|
| python-docx + Pillow | 宣发 Word（裁封面、嵌图、排版）——**核心交付** | ✅ 必装 |
| openpyxl | 仅 Excel 分镜脚本表需要 | 按需 |
| html_to_docx（tencent-docx 插件自带） | 仅文稿 docx 需要；脚本自动定位插件、按需跑其 setup 脚本 | 按需，且依赖 WorkBuddy 环境 |

- 脚本路径用 `S=<本技能目录>/scripts`、解释器用 `PY=python3`，不写死任何机器绝对路径。
- `md_to_docx.py` 的插件目录与 venv 解释器支持环境变量覆盖：
  `TENCENT_DOCX_PLUGIN`、`HTML_TO_DOCX_PY`（未设置时回退到 `~/.workbuddy/...`）。
- 封面图走目标 agent 的文生图能力（如 ImageGen），每次出图消耗额度，**出图前必须告知用户**。

`epmd.py` 是共享解析模块，五个脚本都从它取 md 解析逻辑——改解析规则只改这一处。
